 <!DOCTYPE html>
<html lang="en">
 
<link rel="stylesheet" type="text/css" href="login.css">
	
<body>


<div id="pos">
<p id="heading"><b>USER LOGIN</b></p><br><br>
<form action = "login.php" method="POST">
<input id = "fields" type ="text" name="username" placeholder="Username"><br>
<input id = "fields" type ="text" name="password" placeholder="Password">

<br><br>

&nbsp;&nbsp;&nbsp;<input id ="submit"type = "submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;

<input id = "reset"type ="reset" name ="Reset">
</form>


</div>
</body>
</html>