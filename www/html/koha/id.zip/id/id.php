<html lang="en">

<div id="pos">

<p id ="heading"><b> AKGEC CENTRAL LIBRARY</b></p>

<link rel="stylesheet" type="text/css" href="id.css">


<form action = "output.php" method="POST" autocomplete = "off">
<font color="white"><b>For a particular student:<br><br></font></b>
<input id = "fields" type ="text" name="stnumber" placeholder="Student Number" autofocus><br><br>

<b><font color="white">For printing in a series:</b><br><br></font>
<input id = "fields" type ="text" name="begg" placeholder="Beginning of Student Number in series"><br>
<input id = "fields" type ="text" name ="end" placeholder="End of Student Number in series"><br><br>

<input id ="submit" type ="submit" name="submit">
</form>

</div>
</html>