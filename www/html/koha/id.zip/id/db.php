<?php 
$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'kalilinux';
$db_name = 'koha';
$mysql = new mysqli($db_host,$db_user,$db_pass,$db_name);

if($mysql->connect_error){
	die("Error Connecting to DB.".$mysql->connect_errno. "Error -> " .$mysql->connect_error);
}

 ?>