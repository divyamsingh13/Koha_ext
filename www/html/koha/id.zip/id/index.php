<?php 
include 'db.php';
include 'Barcode39.php';
class student{
	public $bno,$cardnumber,$name,$address,$mob1,$mob2,$branch,$blood,$batch;
	public function __construct($s){
		$this->bno = $s['borrowernumber'];
		$this->batch = 'Batch';
		$this->cardnumber = $s['cardnumber'];
		$this->name = $s["firstname"]." ".$s["surname"];
		$this->address = $s['address']." ".$s['address2'];
		$this->mob1 = $s['mobile'];
		$this->mob2 = $s['phone'];
		$this->branch = $s['sort1'];
		$this->blood = $s['sort2'];
		$this->city = $s['city'];
		$this->zipcode = $s['zipcode'];
		$this->getBlood();
		$this->getBatch();
		$this->getBranch();
	}
	public function getBlood(){
		global $conn,$mysql;
		$sql = "SELECT * FROM `borrower_attributes` WHERE `borrowernumber` = '$this->bno' AND `code` = 'BLD' ;";
			$result = $mysql->query($sql) or die(mysqli_error());
			$row = $result->fetch_array(MYSQLI_ASSOC);
			$this->blood = $row['attribute'];
			//echo '??';
	}
	public function getBatch(){
		global $conn,$mysql;
		$sql = "SELECT * FROM `borrower_attributes` WHERE `borrowernumber` = '$this->bno' AND `code` = 'PAT_YEAR' ;";
			$result = $mysql->query($sql) or die(mysqli_error());
			$row = $result->fetch_array(MYSQLI_ASSOC);
			$this->batch = $row['attribute'];
			//echo '??';
	}
	public function getBranch(){
		global $conn,$mysql;
		$sql = "SELECT * FROM `borrower_attributes` WHERE `borrowernumber` = '$this->bno' AND `code` = 'DEPT' ;";
			$result = $mysql->query($sql) or die(mysqli_error());
			$row = $result->fetch_array(MYSQLI_ASSOC);
			$this->branch = $row['attribute'];
			//echo '??';
	}
}

function CreateICard($s){
	$location='barcode/';
	$bc=new Barcode39($s->cardnumber);
	// set text size 
	//$bc->barcode_lin 
	$bc->barcode_text =false;
	$bc->draw($location.$s->cardnumber.".gif");
	include 'icard.php';
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ID Card Generator</title>
	<link href="http://allfont.net/allfont.css?fonts=arial-narrow" rel="stylesheet" type="text/css" />
	<style type="text/css">
		@font-face {
			font-family: "Bitstream Vera Serif Bold";
		}
		body{
			font-family: 'Arial Narrow',Arial, Helvetica, sans-serif;
			margin: 0;
			padding: 0;
			border: 0;
		}
		#container{
			margin: auto;
			position: relative;
			width:800px;
		}
		.grid2{
		    position: relative;
		    height: 140px;
		}
		.grid3 {
		    position: relative;
		    height: 60px;
		}
		.card{
			display: inline-block;
			padding: 1px;
			position: relative;
			display: inline-block;
			width: 48%;
			height: 260px;
		}
		.cright {
		    position: relative;
		    float: right;
		}
		.akglogo {
		    position: relative;
		    width: 35px;
		    height: 30px;
		    top: 20px;
		    left: 25px;
		}
		.akghead{
			font-family: 'Arial Narrow', arial;
			display: inline-block;
			position: relative;
			width: 295px;
			margin: auto;
			text-align: center;
			left: 30px;
			font-size: 14px;
			font-weight: 400;
		}
		.akginfo {
		    position: relative;
		    width: 300px;
		    text-align: center;
		    font-size: 10px;
		    left: 58px;
		    
		}
		.akgi {
		    margin: 1px 0px 4px 0px;
		}
		.pngimage{
			width: 90px;
			height: 130px;
		}
		.patimage {
		    position: relative;
		    left: 25px;
		    width: 100px;
		    top: -10px;
		}
		.icardtxt{
			text-align: center;
			font-weight: 600;
			font-size: 14px;
			text-decoration: underline;
		}
		.attr, .colons, .val1 {
			
		    font-weight: 600;
		    position: relative;
		    display: inline-block;
		    left: 130px;
		    top: -110px;
		    font-size: 14px;
		}
		.val1{

		}
		.barcode {
		    top: 0;
		    position: relative;
		    left: 80px;
		}
		.dirsign{
			font-weight: 600;
		    position: relative;
		    top: -27px;
		    left: 310px;
		}
		.rules {
		    position: relative;
		    top: 20px;
		    font-size: 12px;
		    font-style: italic;
		    padding:18px
		}
		.icard {
		    position: relative;
		    height: 300px;
		}

		.address {
		    margin-left: 14px;
		    margin-top: 5px;
		}
		.a{
			position: relative;
			margin-right:5px; 
			font-size:14px;
			font-weight: 600;
		}
		.bld{
			margin-bottom:5px;
		}
	</style>
</head>
<body>
<div id="container">
	<div id="main" >
		<?php
		$cno = '1210053';
		$result = $mysql->query("SELECT * from `borrowers` WHERE `cardnumber` = '$cno' ;");
		//$result = $mysql->query("SELECT * from `patronimage`;");
		
		$s=NULL;
		if($result){
			$row = $result->fetch_array(MYSQLI_ASSOC);
			//var_dump($row);
			//echo 'In IF';
			$s = new student($row);
		}

		CreateICard($s);
		 ?>
	</div>
</div>
</body>
</html>

